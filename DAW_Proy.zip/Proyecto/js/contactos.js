

function enviar() {
	var string = document.getElementById("numero").value;
	var re = /[7&6&2][0-9]{7}/;

	if(re.test(string)){
		alert("¡Numero válido!");
	}else{
		alert("¡Numero inválido!");
}//fin else
}//fin function

function enviado() {
	alert("¡Muchas Gracias!");
}




/*Enviaremos los datos a localstorage*/
/*let nombre = parseInt(document.getElementById('nombre')).value;
let apellido = parseInt(document.getElementById('apellido')).value;
let correo = parseInt(document.getElementById('correo')).value;
let telefono = parseInt(document.getElementById('numero')).value;
let pais = parseInt(document.getElementById('pais')).value;

localStorage = nombre, apellido, correo, telefono, pais;
console.log(localStorage);*/
/*
localStorage.setItem("nombre", nombre);
localStorage.setItem("apellido", apellido);
localStorage.setItem("correo", correo);
localStorage.setItem("numero", telefono);
localStorage.setItem("pais", pais);
*/