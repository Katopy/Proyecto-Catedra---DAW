$(document).ready(function () {
  $("i").hide();
});

$(window).load(function () {
  $("i").show();

  var twitter2Pos = $("#twitter2").position();
  var facebook2Pos = $("#facebook2").position();
  var google2Pos = $("#google2").position();
  var instagram2Pos = $("#instagram2").position();
  var img2Pos = $(".she").position();

  $("i").css({
    position: "absolute",
    zIndex: "1",
    top: img2Pos.top + 100,
    left: "47%"
  });

  setTimeout(function () {
    $("#twitter2").animate(
      {
        top: twitter2Pos.top + 10,
        left: twitter2Pos.left - 10,
      },
      600
    );
  }, 250);

  setTimeout(function () {
    $("#twitter2").animate(
      {
        top: twitter2Pos.top,
        left: twitter2Pos.left
      },
      250
    );

    $("#facebook2").animate(
      {
        top: facebook2Pos.top + 10,
        left: facebook2Pos.left - 6
      },
      500
    );
  }, 500);

  setTimeout(function () {
    $("#facebook2").animate(
      {
        top: facebook2Pos.top,
        left: facebook2Pos.left
      },
      250
    );

    $("#google2").animate(
      {
        top: google2Pos.top + 10,
        left: google2Pos.left
      },
      500
    );
  }, 1000);

  setTimeout(function () {
    $("#google2").animate(
      {
        top: google2Pos.top,
        left: google2Pos.left
      },
      250
    );

    $("#instagram2").animate(
      {
        top: instagram2Pos.top + 10,
        left: instagram2Pos.left + 3
      },
      500
    );
  }, 1250);

  setTimeout(function () {
    $("#instagram2").animate(
      {
        top: instagram2Pos.top,
        left: instagram2Pos.left
      },
      250
    );
  }, 1750);
});
