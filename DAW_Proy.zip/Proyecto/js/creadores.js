$(document).ready(function () {
  $("i").hide();
});

$(window).load(function () {
  $("i").show();

  var twitterPos = $("#twitter").position();
  var facebookPos = $("#facebook").position();
  var googlePos = $("#google").position();
  var instagramPos = $("#instagram").position();
  var imgPos = $(".me").position();

  $("i").css({
    position: "relative",
    zIndex: "1",
    top: imgPos.top + 5,
    left: "1%"
  });

  setTimeout(function () {
    $("#twitter").animate(
      {
        top: twitterPos.top + 10,
        left: twitterPos.left - 10,
      },
      500
    );
  }, 250);

  setTimeout(function () {
    $("#twitter").animate(
      {
        top: twitterPos.top,
        left: twitterPos.left
      },
      250
    );

    $("#facebook").animate(
      {
        top: facebookPos.top + 10,
        left: facebookPos.left - 6
      },
      500
    );
  }, 500);

  setTimeout(function () {
    $("#facebook").animate(
      {
        top: facebookPos.top,
        left: facebookPos.left
      },
      250
    );

    $("#google").animate(
      {
        top: googlePos.top + 10,
        left: googlePos.left
      },
      500
    );
  }, 1000);

  setTimeout(function () {
    $("#google").animate(
      {
        top: googlePos.top,
        left: googlePos.left
      },
      250
    );

    $("#instagram").animate(
      {
        top: instagramPos.top + 10,
        left: instagramPos.left + 3
      },
      500
    );
  }, 1250);

  setTimeout(function () {
    $("#instagram").animate(
      {
        top: instagramPos.top,
        left: instagramPos.left
      },
      250
    );
  }, 1750);
});
