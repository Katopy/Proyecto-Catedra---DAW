function mostrar(){
document.getElementById('ahuachapan1').style.display='block';

}
function mostrar1(){
    document.getElementById('SantaAna1').style.display='block';
}
function desaparecer1(){
    document.getElementById('SantaAna1').style.display='none';
}
function mostrar2(){
    document.getElementById('SanMiguel1').style.display='block';
}
function desaparecer2(){
    document.getElementById('SanMiguel1').style.display='none';
}
function mostrar3(){
    document.getElementById('LaLibertad1').style.display='block';
}
function desaparecer3(){
    document.getElementById('LaLibertad1').style.display='none';
}
function mostrar4(){
    document.getElementById('cabañas1').style.display='block';
}
function desaparecer4(){
   // document.getElementById('cabañas1').style.display='none';
}
function mostrar5(){
    document.getElementById('chalatenango1').style.display='block';
}
function desaparecer5(){
    //document.getElementById('chalatenango1').style.display='none';
}
function mostrar6(){
    document.getElementById('Cuscatlán1').style.display='block';
}
function desaparecer6(){
    document.getElementById('Cuscatlán1').style.display='none';
}
function mostrar7(){
    document.getElementById('Morazán1').style.display='block';
}
function desaparecer7(){
    document.getElementById('Morazán1').style.display='none';
}
function mostrar8(){
    document.getElementById('LaPaz1').style.display='block';
}
function desaparecer8(){
    document.getElementById('LaPaz1').style.display='none';
}
function mostrar9(){
    document.getElementById('SanSalvador1').style.display='block';
}
function desaparecer9(){
    document.getElementById('SanSalvador1').style.display='none';
}
function mostrar10(){
    document.getElementById('SanVicente1').style.display='block';
}
function desaparecer10(){
    document.getElementById('SanVicente1').style.display='none';
}
function mostrar11(){
    document.getElementById('Sonsonate1').style.display='block';
}
function desaparecer11(){
    document.getElementById('Sonsonate1').style.display='none';
}
function mostrar12(){
    document.getElementById('LaUnion1').style.display='block';
}
function desaparecer12(){
    document.getElementById('LaUnion1').style.display='none';
}
function mostrar13(){
    document.getElementById('Usulután1').style.display='block';
}
function desaparecer13(){
    document.getElementById('Usulután1').style.display='none';
}
function mostrar14(){
    document.getElementById('Sonsonate1').style.display='block';
}
function desaparecer14(){
    document.getElementById('Sonsonate1').style.display='none';
}
function desaparecer(){
 //document.getElementById('ahuachapan1').style.display='none';
}