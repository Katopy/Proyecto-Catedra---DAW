
var inputs =  document.querySelectorAll("input[type='text'], input[type='number'], input[type='email']");
//Obtiene y coloca el LocalStorage de text/number/email del forms y input
Array.prototype.forEach.call(inputs, function (el, index, array) {
	//Captura los elementos de ID y lo coloca como propiedad de localStorage
	var datosname = el.getAttribute("id"),
	// set dataStored var
		datosStored = localStorage.getItem(datosname);
	// if dataStored set input value to data
	if(datosStored)
		el.value = localStorage.getItem(datosname);
	
	// on blur save data input
	el.addEventListener('blur', function (event) {
		localStorage.setItem(datosname, event.target.value);
		console.log(localStorage.getItem(datosname));
	});
}); 

// for simple debugging
console.log(localStorage)
function logStorage(){
	console.log(localStorage);
}
function clearStorage(){
	localStorage.clear();
	logStorage();
}

